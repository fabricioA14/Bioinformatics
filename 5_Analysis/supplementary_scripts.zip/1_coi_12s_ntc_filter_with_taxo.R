## Impacts of replicates, polymerase and amplicon size to unravel species richness across habitats using eDNA metabarcoding ##
## Anmarkrud, J.A.; Thorbek, L.; Schrøder-Nielsen, A.; Rosa, F.A.S.; Melo, S.; Ready, J.S.; de Boer, H.; Mauvisseau Q.; ######
## Corresponding author: Quentin Mauvisseau - quentin.mauvisseau@nhm.uio.no  #################################################

######################################## COI ########################################

################# OTUs #################

# Setting working directories
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/coi_otu_taxo")

# Load required packages
pack <- c('tibble','stringr','data.table','DescTools','writexl','dplyr','ggplot2','car',
          'MASS','ggpubr')
vars <- pack[!(pack %in% installed.packages()[, "Package"])]
if (length(vars != 0)) {
  install.packages(vars, dependencies = TRUE)
} 
sapply(pack, require, character.only = TRUE)

###############################################################################

csv <- read.csv("otutab_COI_with_taxo.txt",na.strings = c(""),stringsAsFactors = FALSE, sep = "")

csv <- csv[,c(13:ncol(csv))]

#Sum before NTC removal
#sum(as.matrix(csv[, !grepl("^NTC", colnames(csv))]), na.rm = TRUE)

# AG
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern ACCU
  polymerase <- replicates[, str_detect(colnames(replicates), "AG")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
AG <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# ACCU
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern ACCU
  polymerase <- replicates[, str_detect(colnames(replicates), "ACCU")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
ACCU <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# Q
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern QPOL5
  polymerase <- replicates[, str_detect(colnames(replicates), "QPOL5")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
Q <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

#################################################################

# Combine AG, ACCU, and Q data into one dataset
ntc.filter.dataset <- data.frame(AG, ACCU, Q)

#Sum after NTC removal
#sum(as.matrix(ntc.filter.dataset[, !grepl("^NTC", colnames(ntc.filter.dataset))]), na.rm = TRUE)

# Remove columns with 'NTC' in their names
ntc.filter.dataset_ <- ntc.filter.dataset[, !grepl('NTC', names(ntc.filter.dataset))]

#OTUs sum
sum(rowSums(ntc.filter.dataset_) > 0)

# Save the final dataset to a CSV file
write.csv(ntc.filter.dataset_, "C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/coi_otu_taxo/ntc.filter.otu.coi.dataset.csv", row.names = F)

# Clean up the workspace, removing all objects except the ones specified
rm(list=setdiff(ls(), c("")))

################# ASVs #################

# Setting working directories
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/coi_zotu_taxo")

csv <- read.csv("zotutab_COI_with_taxo.txt",na.strings = c(""),stringsAsFactors = FALSE, sep = "")

csv <- csv[,c(13:ncol(csv))]

#Sum before NTC removal
#sum(as.matrix(csv[, !grepl("^NTC", colnames(csv))]), na.rm = TRUE)

# AG
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern AG
  polymerase <- replicates[, str_detect(colnames(replicates), "AG")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
AG <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# ACCU
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern ACCU
  polymerase <- replicates[, str_detect(colnames(replicates), "ACCU")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
ACCU <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# Q
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern QPOL5
  polymerase <- replicates[, str_detect(colnames(replicates), "QPOL5")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
Q <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

#################################################################

# Combine AG, ACCU, and Q data into one dataset
ntc.filter.dataset <- data.frame(AG, ACCU, Q)

#Sum after NTC removal
#sum(as.matrix(ntc.filter.dataset[, !grepl("^NTC", colnames(ntc.filter.dataset))]), na.rm = TRUE)

# Remove columns with 'NTC' in their names
ntc.filter.dataset_ <- ntc.filter.dataset[, !grepl('NTC', names(ntc.filter.dataset))]

#ZOTUs sum
sum(rowSums(ntc.filter.dataset_) > 0)

# Write the filtered dataset to a CSV file
write.csv(ntc.filter.dataset_, "C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/coi_zotu_taxo/ntc.filter.zotu.coi.dataset.csv", row.names = F)

# Clean up the workspace, removing all objects except the ones specified
rm(list=setdiff(ls(), c("")))


######################################## 12s ########################################

################# OTUs #################

# Setting working directories
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/12s_otu_taxo")

csv <- read.csv("otutab_12S.txt",na.strings = c(""),stringsAsFactors = FALSE, sep = "")

csv_taxo <- read.csv("otutab_12S_taxo.txt",na.strings = c(""),stringsAsFactors = FALSE, sep = "\t", header = FALSE)

# Exclude non-identified OTUs
csv_taxo_filtered <- csv_taxo[!(rowSums(is.na(csv_taxo[, 2:5])) == 4), ]

csv <- csv[csv$X.OTU %like% csv_taxo_filtered$V1, ] ; csv <- type.convert(csv) ; csv <- csv[,3:ncol(csv)]

#Sum before NTC removal
sum(as.matrix(csv[, !grepl("^NTC", colnames(csv))]), na.rm = TRUE)

# AG
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern AG
  polymerase <- replicates[, str_detect(colnames(replicates), "AG")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
AG <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# ACCU
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern ACCU
  polymerase <- replicates[, str_detect(colnames(replicates), "ACCU")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
ACCU <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# Q
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern QPOL5
  polymerase <- replicates[, str_detect(colnames(replicates), "QPOL5")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
Q <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

#################################################################

# Combine AG, ACCU, and Q data into one dataset
ntc.filter.dataset <- data.frame(AG, ACCU, Q)

#Sum after NTC removal
#sum(as.matrix(ntc.filter.dataset[, !grepl("^NTC", colnames(ntc.filter.dataset))]), na.rm = TRUE)

# Remove columns with 'NTC' in their names
ntc.filter.dataset_ <- ntc.filter.dataset[, !grepl('NTC', names(ntc.filter.dataset))]

#OTUs sum
sum(rowSums(ntc.filter.dataset_, na.rm = TRUE) > 0)

# Write the filtered dataset to a CSV file
write.csv(ntc.filter.dataset_, "C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/12s_taxo/ntc.filter.otu.12S.dataset.csv", row.names = F)

# Clean up the workspace, removing all objects except the ones specified
rm(list=setdiff(ls(), c("")))


################# ASVs #################

# Setting working directories
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/12s_zotu_taxo")

###############################################################################

csv <- read.csv("zotutab_12S.txt",na.strings = c(""),stringsAsFactors = FALSE, sep = "")

csv_taxo <- read.csv("zotutab_12S_taxo.txt",na.strings = c(""),stringsAsFactors = FALSE, sep = "\t", header = FALSE)

# Exclude non identified ASVs
csv_taxo_filtered <- csv_taxo[!(rowSums(is.na(csv_taxo[, 2:4])) == 3), ]

csv <- csv[csv$X.OTU %like% csv_taxo_filtered$V1, ] ; csv <- type.convert(csv) ; csv <- csv[,3:ncol(csv)]

#Sum before NTC removal
#sum(as.matrix(csv[, !grepl("^NTC", colnames(csv))]), na.rm = TRUE)

# AG
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern AG
  polymerase <- replicates[, str_detect(colnames(replicates), "AG")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
AG <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# ACCU
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern ACCU
  polymerase <- replicates[, str_detect(colnames(replicates), "ACCU")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
ACCU <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# Q
# Function to create objects dynamically
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern QPOL5
  polymerase <- replicates[, str_detect(colnames(replicates), "QPOL5")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
Q <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

#################################################################

# Combine AG, ACCU, and Q data into one dataset
ntc.filter.dataset <- data.frame(AG, ACCU, Q)

#Sum after NTC removal
#sum(as.matrix(ntc.filter.dataset[, !grepl("^NTC", colnames(ntc.filter.dataset))]), na.rm = TRUE)

# Remove columns with 'NTC' in their names
ntc.filter.dataset_ <- ntc.filter.dataset[, !grepl('NTC', names(ntc.filter.dataset))]

#ZOTUs sum
#sum(rowSums(ntc.filter.dataset_, na.rm = TRUE) > 0)

# Write the filtered dataset to a CSV file
write.csv(ntc.filter.dataset_, "C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/12s_zotu_taxo/ntc.filter.zotu.12S.dataset.csv", row.names = F)

# Clean up the workspace, removing all objects except the ones specified
rm(list=setdiff(ls(), c("")))









