## Impacts of replicates, polymerase and amplicon size to unravel species richness across habitats using eDNA metabarcoding ##
## Anmarkrud, J.A.; Thorbek, L.; Schrøder-Nielsen, A.; Rosa, F.A.S.; Melo, S.; Ready, J.S.; de Boer, H.; Mauvisseau Q.; ######
## Corresponding author: Quentin Mauvisseau - quentin.mauvisseau@nhm.uio.no  #################################################

############  Plot  #######################

# Last points for OTU
last_points_otu <- csv %>%
  filter(method == "Otu") %>%
  filter(sample_polymerase == paste0(Name_of_Run)) %>%
  group_by(replicate) %>%
  filter(site == max(site)) %>%
  slice(1) %>%
  ungroup() %>%
  mutate(last_site = site, last_richness = richness, type = "Otu") %>%
  dplyr::select(replicate, last_site, last_richness, type)

# Last points for ZOTU
last_points_zotu <- csv %>%
  filter(method == "Zotu") %>%
  filter(sample_polymerase == paste0(Name_of_Run)) %>%
  group_by(replicate) %>%
  filter(site == max(site)) %>%
  slice(1) %>%
  ungroup() %>%
  mutate(last_site = site, last_richness = richness, type = "Zotu") %>%
  dplyr::select(replicate, last_site, last_richness, type)

# Combine both objects into one
last_points_combined <- as.data.frame(bind_rows(last_points_otu, last_points_zotu))

#last_points_combined$type <- as.factor(last_points_combined$type)

csv_ <- csv %>%
  filter(sample_polymerase == paste0(Name_of_Run))

g <- csv_ %>%
  ggplot(aes(site, richness, group = grouped_approaches, color = replicate)) +  # Map 'method' to 'linetype'
  scale_x_continuous(expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 450), breaks = seq(0, 450, by = 100)) +
  geom_line(aes(linetype = method), size = 1.2) +
  scale_linetype_manual(values = c("Otu" = "solid", "Zotu" = "dashed")) +
  geom_point(data = last_points_combined, 
             aes(x = last_site, y = last_richness, group = replicate, shape = type, fill = replicate),  # Map 'type' to 'shape' and 'fill'
             size = 5, stroke = 2, color = "white") +  # Set white border with stroke
  scale_shape_manual(values = c("Otu" = 21, "Zotu" = 24)) +  # Set different shapes
  geom_ribbon(aes(ymin = richness - 0.7 * sd, ymax = richness + 0.7 * sd, fill = replicate), color = NA, alpha = 0.3) +
  coord_cartesian(xlim = c(min(csv$site), max(csv$site) + 1)) +
  xlab("Technical Replicates") + 
  ylab("Richness") + 
  theme(
    legend.position = "bottom",
    legend.title = element_blank(),
    text = element_text(size = 18),
    legend.box = "vertical",
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_blank(),
    plot.title = element_text(hjust = 0.5),
    axis.line = element_line(color = "grey80"),
    axis.ticks = element_line(color = "grey80"),
    panel.background = element_rect(fill = "white")
  )
g

assign(Name_of_Run, g)

print(paste("Object", Name_of_Run, "created"))

