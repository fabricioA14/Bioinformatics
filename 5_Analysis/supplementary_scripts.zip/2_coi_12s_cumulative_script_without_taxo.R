## Impacts of replicates, polymerase and amplicon size to unravel species richness across habitats using eDNA metabarcoding ##
## Anmarkrud, J.A.; Thorbek, L.; Schrøder-Nielsen, A.; Rosa, F.A.S.; Melo, S.; Ready, J.S.; de Boer, H.; Mauvisseau Q.; ######
## Corresponding author: Quentin Mauvisseau - quentin.mauvisseau@nhm.uio.no  #################################################

######################################## COI ########################################

################# OTUs #################

#Set the directory
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu")

#Load packages
pack <- c('tibble','stringr','data.table','DescTools','writexl','dplyr','ggplot2','car',
          'MASS','ggpubr','readxl','gridExtra','iNEXT','magrittr','vegan','cowplot')
vars <- pack[!(pack %in% installed.packages()[, "Package"])]
if (length(vars != 0)) {
  install.packages(vars, dependencies = TRUE)
} 
sapply(pack, require, character.only = TRUE)

####################################################################################################

csv <- read.csv("ntc.filter.otu.coi.dataset.csv",stringsAsFactors = FALSE, sep = ",")

#csv <- csv[, !grepl(c('NTC'), names(csv))]
#csv <- csv[, !grepl(c('X'), names(csv))]
csv <- csv %>% t() %>% data.frame()

Freq.O <- csv

#colnames(Freq.O) <- Freq.O[1,]

#Freq.O<- Freq.O[-c(1),]

#Freq.O <- Freq.O %>% type.convert()

Freq.O[Freq.O != 0] <- 1

Freq.O <- Freq.O %>% add_column(Sampling_Unit = rownames(Freq.O), .before = 1)

Freq <- Freq.O

rm(Freq.O,csv)

Freq$Polymerase <- ifelse(grepl("AG", Freq$Sampling_Unit), "AG", 
                          ifelse(grepl("ACCU", Freq$Sampling_Unit), 
                                 "ACCU", "QPOL5"))
Freq$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Freq$Sampling_Unit), "Marine", 
                           ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Freq$Sampling_Unit), 
                                  "Freshwater", "Soil"))

#Method
Extrapolation = FALSE

### ACCU SOIL ###

Name_of_Run <- "ACCU_SOIL"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu/run.R")
})

ACCU_SOIL

### AG SOIL ###

Name_of_Run <- "AG_SOIL"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu/run.R")
})

AG_SOIL

### Q SOIL ###

Name_of_Run <- "Q_SOIL"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu/run.R")
})

Q_SOIL

#rm(list=setdiff(ls(), c("Freq","ACCU_SOIL","AG_SOIL","Q_SOIL")))

### ACCU FRESHWATER ###

Name_of_Run <- "ACCU_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu/run.R")
})

ACCU_FRESHWATER

### AG FRESHWATER ###

Name_of_Run <- "AG_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu/run.R")
})

AG_FRESHWATER

### Q FRESHWATER ###

Name_of_Run <- "Q_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu/run.R")
})

Q_FRESHWATER

### ACCU MARINE ###

Name_of_Run <- "ACCU_MARINE"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu/run.R")
})

ACCU_MARINE

### AG MARINE ###

Name_of_Run <- "AG_MARINE"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu/run.R")
})

AG_MARINE

### Q MARINE ###

Name_of_Run <- "Q_MARINE"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu/run.R")
})

Q_MARINE

#rm(list=setdiff(ls(), c("Freq","ACCU_SOIL","AG_SOIL","Q_SOIL","ACCU_FRESHWATER","AG_FRESHWATER","Q_FRESHWATER","ACCU_MARINE","AG_MARINE","Q_MARINE")))

plot_grid(ACCU_FRESHWATER,AG_FRESHWATER,Q_FRESHWATER,
          ACCU_MARINE,AG_MARINE,Q_MARINE,
          ACCU_SOIL,AG_SOIL,Q_SOIL,
          align = 'v',
          nrow = 3) #20x14

#labels = c('Accustart Freshwater', 'Q5 Freshwater', 'Amplitaq Gold Freshwater')

###############################################################################

dfs <- ls(pattern = "_df$")
df_list <- lapply(dfs, get)
freq_otu <- do.call(rbind, df_list)
freq_otu$method <- rep("Otu", 1342)


################# ASVs #################

#Set the directory
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu")

#Load packages
pack <- c('tibble','stringr','data.table','DescTools','writexl','dplyr','ggplot2','car',
          'MASS','ggpubr','readxl','gridExtra','iNEXT','magrittr','vegan','cowplot')
vars <- pack[!(pack %in% installed.packages()[, "Package"])]
if (length(vars != 0)) {
  install.packages(vars, dependencies = TRUE)
} 
sapply(pack, require, character.only = TRUE)

####################################################################################################

csv <- read.csv("ntc.filter.zotu.coi.dataset.csv",stringsAsFactors = FALSE, sep = ",")

#csv <- csv[, !grepl(c('NTC'), names(csv))]
#csv <- csv[, !grepl(c('X'), names(csv))]
csv <- csv %>% t() %>% data.frame()

Freq.O <- csv

#colnames(Freq.O) <- Freq.O[1,]

#Freq.O<- Freq.O[-c(1),]

#Freq.O <- Freq.O %>% type.convert()

Freq.O[Freq.O != 0] <- 1

Freq.O <- Freq.O %>% add_column(Sampling_Unit = rownames(Freq.O), .before = 1)

Freq <- Freq.O

Freq$Polymerase <- ifelse(grepl("AG", Freq$Sampling_Unit), "AG", 
                          ifelse(grepl("ACCU", Freq$Sampling_Unit), 
                                 "ACCU", "QPOL5"))
Freq$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Freq$Sampling_Unit), "Marine", 
                           ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Freq$Sampling_Unit), 
                                  "Freshwater", "Soil"))

#Method
Extrapolation = FALSE

### ACCU SOIL ###

Name_of_Run <- "ACCU_SOIL"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu/run.R")
})

ACCU_SOIL

### AG SOIL ###

Name_of_Run <- "AG_SOIL"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu/run.R")
})

AG_SOIL

### Q SOIL ###

Name_of_Run <- "Q_SOIL"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu/run.R")
})

Q_SOIL

#rm(list=setdiff(ls(), c("Freq","ACCU_SOIL","AG_SOIL","Q_SOIL")))

### ACCU FRESHWATER ###

Name_of_Run <- "ACCU_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu/run.R")
})

ACCU_FRESHWATER

### AG FRESHWATER ###

Name_of_Run <- "AG_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu/run.R")
})

AG_FRESHWATER

### Q FRESHWATER ###

Name_of_Run <- "Q_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu/run.R")
})

Q_FRESHWATER

### ACCU MARINE ###

Name_of_Run <- "ACCU_MARINE"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu/run.R")
})

ACCU_MARINE

### AG MARINE ###

Name_of_Run <- "AG_MARINE"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu/run.R")
})

AG_MARINE

### Q MARINE ###

Name_of_Run <- "Q_MARINE"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu/run.R")
})

Q_MARINE

#rm(list=setdiff(ls(), c("Freq","ACCU_SOIL","AG_SOIL","Q_SOIL","ACCU_FRESHWATER","AG_FRESHWATER","Q_FRESHWATER","ACCU_MARINE","AG_MARINE","Q_MARINE")))

plot_grid(ACCU_FRESHWATER,AG_FRESHWATER,Q_FRESHWATER,
          ACCU_MARINE,AG_MARINE,Q_MARINE,
          ACCU_SOIL,AG_SOIL,Q_SOIL,
          align = 'v',
          nrow = 3) #20x14

#labels = c('Accustart Freshwater', 'Q5 Freshwater', 'Amplitaq Gold Freshwater')

###############################################################

dfs <- ls(pattern = "_df$")

# 2. Use lapply para obter os dataframes
df_list <- lapply(dfs, get)
freq_zotu <- do.call(rbind, df_list)
freq_zotu$method <- rep("Zotu", 1341)


##############################################################

freq_general <- rbind(freq_otu, freq_zotu)

freq_general$grouped_approaches <- paste0(freq_general$replicate,"_",freq_general$method)

write.csv(freq_general, "C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all/merged_freqs.csv", row.names = F)


######################################## COI (OTUs & ASVs) ########################################


#Set the directory
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all")

#Load packages
pack <- c('tibble','stringr','data.table','DescTools','writexl','dplyr','ggplot2','car',
          'MASS','ggpubr','readxl','gridExtra','iNEXT','magrittr','vegan','cowplot')
vars <- pack[!(pack %in% installed.packages()[, "Package"])]
if (length(vars != 0)) {
  install.packages(vars, dependencies = TRUE)
} 
sapply(pack, require, character.only = TRUE)

####################################################################################################

csv <- read.csv("merged_freqs.csv",stringsAsFactors = FALSE, sep = ",")

### ACCU SOIL ###

Name_of_Run <- "ACCU_SOIL"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all/run_2.R")
})

ACCU_SOIL

### AG SOIL ###

Name_of_Run <- "AG_SOIL"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all/run_2.R")
})

AG_SOIL

### Q SOIL ###

Name_of_Run <- "Q_SOIL"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all/run_2.R")
})

Q_SOIL

#rm(list=setdiff(ls(), c("Freq","ACCU_SOIL","AG_SOIL","Q_SOIL")))

### ACCU FRESHWATER ###

Name_of_Run <- "ACCU_FRESHWATER"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all/run_2.R")
})

ACCU_FRESHWATER

### AG FRESHWATER ###

Name_of_Run <- "AG_FRESHWATER"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all/run_2.R")
})

AG_FRESHWATER

### Q FRESHWATER ###

Name_of_Run <- "Q_FRESHWATER"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all/run_2.R")
})

Q_FRESHWATER

### ACCU MARINE ###

Name_of_Run <- "ACCU_MARINE"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all/run_2.R")
})

ACCU_MARINE

### AG MARINE ###

Name_of_Run <- "AG_MARINE"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all/run_2.R")
})

AG_MARINE

### Q MARINE ###

Name_of_Run <- "Q_MARINE"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all/run_2.R")
})

Q_MARINE

#rm(list=setdiff(ls(), c("Freq","ACCU_SOIL","AG_SOIL","Q_SOIL","ACCU_FRESHWATER","AG_FRESHWATER","Q_FRESHWATER","ACCU_MARINE","AG_MARINE","Q_MARINE")))

plot_grid(ACCU_FRESHWATER,AG_FRESHWATER,Q_FRESHWATER,
          ACCU_MARINE,AG_MARINE,Q_MARINE,
          ACCU_SOIL,AG_SOIL, Q_SOIL,
          align = 'v',
          nrow = 3) #19x18

################# OTUs #################

#Set the directory
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu")

csv <- read.csv("ntc.filter.otu.12S.dataset.csv",stringsAsFactors = FALSE, sep = ",")

#csv <- csv[, !grepl(c('NTC'), names(csv))]
#csv <- csv[, !grepl(c('X'), names(csv))]
csv <- csv %>% t() %>% data.frame()

Freq.O <- csv

#colnames(Freq.O) <- Freq.O[1,]

#Freq.O<- Freq.O[-c(1),]

#Freq.O <- Freq.O %>% type.convert()

Freq.O[Freq.O != 0] <- 1

Freq.O <- Freq.O %>% add_column(Sampling_Unit = rownames(Freq.O), .before = 1)

Freq <- Freq.O

Freq$Polymerase <- ifelse(grepl("AG", Freq$Sampling_Unit), "AG", 
                          ifelse(grepl("ACCU", Freq$Sampling_Unit), 
                                 "ACCU", "QPOL5"))
Freq$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Freq$Sampling_Unit), "Marine", 
                           ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Freq$Sampling_Unit), 
                                  "Freshwater", "Soil"))

#Method
Extrapolation = FALSE

### ACCU SOIL ###

Name_of_Run <- "ACCU_SOIL"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu/run.R")
})

ACCU_SOIL

### AG SOIL ###

Name_of_Run <- "AG_SOIL"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu/run.R")
})

AG_SOIL

### Q SOIL ###

Name_of_Run <- "Q_SOIL"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu/run.R")
})

Q_SOIL

#rm(list=setdiff(ls(), c("Freq","ACCU_SOIL","AG_SOIL","Q_SOIL")))

### ACCU FRESHWATER ###

Name_of_Run <- "ACCU_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu/run.R")
})

ACCU_FRESHWATER

### AG FRESHWATER ###

Name_of_Run <- "AG_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu/run.R")
})

AG_FRESHWATER

### Q FRESHWATER ###

Name_of_Run <- "Q_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu/run.R")
})

Q_FRESHWATER

### ACCU MARINE ###

Name_of_Run <- "ACCU_MARINE"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu/run.R")
})

ACCU_MARINE

### AG MARINE ###

Name_of_Run <- "AG_MARINE"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu/run.R")
})

AG_MARINE

### Q MARINE ###

Name_of_Run <- "Q_MARINE"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu/run.R")
})

Q_MARINE

#rm(list=setdiff(ls(), c("Freq","ACCU_SOIL","AG_SOIL","Q_SOIL","ACCU_FRESHWATER","AG_FRESHWATER","Q_FRESHWATER","ACCU_MARINE","AG_MARINE","Q_MARINE")))

plot_grid(ACCU_FRESHWATER,AG_FRESHWATER,Q_FRESHWATER,
          ACCU_MARINE,AG_MARINE,Q_MARINE,
          ACCU_SOIL,AG_SOIL,Q_SOIL,
          align = 'v',
          nrow = 3) #20x14

#labels = c('Accustart Freshwater', 'Q5 Freshwater', 'Amplitaq Gold Freshwater')

dfs <- ls(pattern = "_df$")
df_list <- lapply(dfs, get)
freq_otu <- do.call(rbind, df_list)
freq_otu$method <- rep("Otu", 1348)


################# ASVs #################


csv <- read.csv("ntc.filter.zotu.12S.dataset.csv",stringsAsFactors = FALSE, sep = ",")

#csv <- csv[, !grepl(c('NTC'), names(csv))]
#csv <- csv[, !grepl(c('X'), names(csv))]
csv <- csv %>% t() %>% data.frame()

Freq.O <- csv

#colnames(Freq.O) <- Freq.O[1,]

#Freq.O<- Freq.O[-c(1),]

#Freq.O <- Freq.O %>% type.convert()

Freq.O[Freq.O != 0] <- 1

Freq.O <- Freq.O %>% add_column(Sampling_Unit = rownames(Freq.O), .before = 1)

Freq <- Freq.O

Freq$Polymerase <- ifelse(grepl("AG", Freq$Sampling_Unit), "AG", 
                          ifelse(grepl("ACCU", Freq$Sampling_Unit), 
                                 "ACCU", "QPOL5"))
Freq$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Freq$Sampling_Unit), "Marine", 
                           ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Freq$Sampling_Unit), 
                                  "Freshwater", "Soil"))

#Method
Extrapolation = FALSE

### ACCU SOIL ###

Name_of_Run <- "ACCU_SOIL"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_zotu/run.R")
})

ACCU_SOIL

### AG SOIL ###

Name_of_Run <- "AG_SOIL"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_zotu/run.R")
})

AG_SOIL

### Q SOIL ###

Name_of_Run <- "Q_SOIL"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Soil",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_zotu/run.R")
})

Q_SOIL

### ACCU FRESHWATER ###

Name_of_Run <- "ACCU_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_zotu/run.R")
})

ACCU_FRESHWATER

### AG FRESHWATER ###

Name_of_Run <- "AG_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_zotu/run.R")
})

AG_FRESHWATER

### Q FRESHWATER ###

Name_of_Run <- "Q_FRESHWATER"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Freshwater",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_zotu/run.R")
})

Q_FRESHWATER

### ACCU MARINE ###

Name_of_Run <- "ACCU_MARINE"

Polymerase <- Freq[Freq$Polymerase == "ACCU",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_zotu/run.R")
})

ACCU_MARINE

### AG MARINE ###

Name_of_Run <- "AG_MARINE"

Polymerase <- Freq[Freq$Polymerase == "AG",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_zotu/run.R")
})

AG_MARINE

### Q MARINE ###

Name_of_Run <- "Q_MARINE"

Polymerase <- Freq[Freq$Polymerase == "QPOL5",]
Sample_Type <- Polymerase[Polymerase$Sample_Type == "Marine",]

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_zotu/run.R")
})

Q_MARINE

plot_grid(ACCU_FRESHWATER,AG_FRESHWATER,Q_FRESHWATER,
          ACCU_MARINE,AG_MARINE,Q_MARINE,
          ACCU_SOIL,AG_SOIL,Q_SOIL,
          align = 'v',
          nrow = 3) #20x14

#Reorder 
dfs <- ls(pattern = "_df$")
df_list <- lapply(dfs, get)
freq_zotu <- do.call(rbind, df_list)
freq_zotu$method <- rep("Zotu", 1342)

freq_general <- rbind(freq_otu, freq_zotu)

freq_general$grouped_approaches <- paste0(freq_general$replicate,"_",freq_general$method)

write.csv(freq_general, "C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all/merged_freqs.csv", row.names = F)


######################################## COI (OTUs & ASVs) ########################################

#Set the directory
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all")

csv <- read.csv("merged_freqs.csv",stringsAsFactors = FALSE, sep = ",")

### ACCU SOIL ###

Name_of_Run <- "ACCU_SOIL"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all/run.R")
})

ACCU_SOIL

### AG SOIL ###

Name_of_Run <- "AG_SOIL"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all/run.R")
})

AG_SOIL

### Q SOIL ###

Name_of_Run <- "Q_SOIL"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all/run.R")
})

Q_SOIL


### ACCU FRESHWATER ###

Name_of_Run <- "ACCU_FRESHWATER"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all/run.R")
})

ACCU_FRESHWATER

### AG FRESHWATER ###

Name_of_Run <- "AG_FRESHWATER"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all/run.R")
})

AG_FRESHWATER

### Q FRESHWATER ###

Name_of_Run <- "Q_FRESHWATER"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all/run.R")
})

Q_FRESHWATER

### ACCU MARINE ###

Name_of_Run <- "ACCU_MARINE"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all/run.R")
})

ACCU_MARINE

### AG MARINE ###

Name_of_Run <- "AG_MARINE"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all/run.R")
})

AG_MARINE

### Q MARINE ###

Name_of_Run <- "Q_MARINE"

tryCatch({
  source("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all/run.R")
})

Q_MARINE


plot_grid(ACCU_FRESHWATER,AG_FRESHWATER,Q_FRESHWATER,
          ACCU_MARINE,AG_MARINE,Q_MARINE,
          ACCU_SOIL,AG_SOIL,Q_SOIL,
          align = 'v',
          nrow = 3) #19x18
