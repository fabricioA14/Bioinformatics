## Impacts of replicates, polymerase and amplicon size to unravel species richness across habitats using eDNA metabarcoding ##
## Anmarkrud, J.A.; Thorbek, L.; Schrøder-Nielsen, A.; Rosa, F.A.S.; Melo, S.; Ready, J.S.; de Boer, H.; Mauvisseau Q.; ######
## Corresponding author: Quentin Mauvisseau - quentin.mauvisseau@nhm.uio.no  #################################################

Sample_Type$Replicate <- ifelse(grepl("R10", Sample_Type$Sampling_Unit), "R10", 
                         ifelse(grepl("R2", Sample_Type$Sampling_Unit), "R2",
                                ifelse(grepl("R3", Sample_Type$Sampling_Unit), "R3",
                                       ifelse(grepl("R4", Sample_Type$Sampling_Unit), "R4",
                                              ifelse(grepl("R5", Sample_Type$Sampling_Unit), "R5",
                                                     ifelse(grepl("R6", Sample_Type$Sampling_Unit), "R6",
                                                            ifelse(grepl("R7", Sample_Type$Sampling_Unit), "R7",
                                                                   ifelse(grepl("R8", Sample_Type$Sampling_Unit), "R8",
                                                                          ifelse(grepl("R9", Sample_Type$Sampling_Unit), "R9","R1")))))))))
summary(Sample_Type)

#Richness
#Raw.Richness <- Sample_Type %>% add_column(Raw.Richness = rowSums(sapply(Sample_Type, is.numeric)), .before = 2)

# Add a new column 'Raw.Richness' with row sums of numeric columns
Raw.Richness <- Sample_Type %>%
  mutate(Raw.Richness = rowSums(select_if(., is.numeric))) %>%
  relocate(Raw.Richness, .after = 1)

#Exclude rows with NA values
Raw.Richness <- na.omit(Raw.Richness)

Richness <- Sample_Type[sapply(Sample_Type, is.numeric)]

#Exclude rows with NA values
Richness <- na.omit(Richness)

# Identify columns with colsums = 0
zero_sum_columns <- colSums(Richness) == 0

# Exclude columns with colsums = 0
filtered_data <- Richness[, !zero_sum_columns]

if (Extrapolation == TRUE) {

#Concatenate the Replicate + Richness column with the filtered dataset
data <- data.frame(Replicate = Raw.Richness$Replicate, Richness = Raw.Richness$Raw.Richness,
                   filtered_data)

##### ONE NATURAL REPLICATE #####

# Select  natural replicate with smallest value
one_natural_replicate <- data %>%
  group_by(Replicate) %>%
  slice_min(order_by = Richness, n = 1) ; one_natural_replicate <- one_natural_replicate[-11,]

# Replace the number 2 with 1 in the entire data frame
one_natural_replicate <- one_natural_replicate %>%
  mutate_at(vars(3:ncol(.)), ~ replace(., . > 1, 1)) %>% data.frame()

one <- one_natural_replicate[,-2]; one <- data.frame(t(one)); colnames(one) <- one[1,] ; one <- one[-1,] ; one <- type.convert(one)

##### TWO NATURAL REPLICATES #####

# Select and sum the three natural replicates wit smallest values
two_natural_replicates <- data %>%
  group_by(Replicate) %>%
  slice_min(order_by = Richness, n = 2) ; two_natural_replicates <- two_natural_replicates[-13,]

# Replace the number 2 with 1 in the entire data frame
two_natural_replicates <- two_natural_replicates %>%
  mutate_at(vars(3:ncol(.)), ~ replace(., . > 1, 1)) %>% data.frame()

two <- two_natural_replicates[,-2]; two <- data.frame(t(two)); colnames(two) <- two[1,] ; two <- two[-1,] ; two <- type.convert(two)

##### THREE NATURAL REPLICATES #####

# Select and sum the three natural replicates wit smallest values
three_natural_replicates <- data %>%
  group_by(Replicate) %>%
  slice_min(order_by = Richness, n = 3)

# Replace the number 2 with 1 in the entire data frame
three_natural_replicates <- three_natural_replicates %>%
  mutate_at(vars(3:ncol(.)), ~ replace(., . > 1, 1)) %>% data.frame()

three <- three_natural_replicates[,-2]; three <- data.frame(t(three)); colnames(three) <- three[1,] ; three <- three[-1,] ; three <- type.convert(three)

##### FOUR NATURAL REPLICATES #####

# Select and sum the four natural replicates wit smallest values
four_natural_replicates <- data %>%
  group_by(Replicate) %>%
  slice_min(order_by = Richness, n = 4)

# Replace the number 2 with 1 in the entire data frame
four_natural_replicates <- four_natural_replicates %>%
  mutate_at(vars(3:ncol(.)), ~ replace(., . > 1, 1)) %>% data.frame()

four <- four_natural_replicates[,-2]; four <- data.frame(t(four)); colnames(four) <- four[1,] ; four <- four[-1,] ; four <- type.convert(four)

##### FIVE NATURAL REPLICATES #####

# Select and sum the five natural replicates wit smallest values
five_natural_replicates <- data %>%
  group_by(Replicate) %>%
  slice_min(order_by = Richness, n = 5)

# Replace the number 2 with 1 in the entire data frame
five_natural_replicates <- five_natural_replicates %>%
  mutate_at(vars(3:ncol(.)), ~ replace(., . > 1, 1)) %>% data.frame()

five <- five_natural_replicates[,-2]; five <- data.frame(t(five)); colnames(five) <- five[1,] ; five <- five[-1,] ; five <- type.convert(five)

#raw_list <- list(One = cumulative_1,Two = cumulative_2,Three = cumulative_3,Four = cumulative_4, Five = cumulative_5)
raw_list <- list(One = one,Two = two,Three = three,Four = four, Five = five)

t <- seq(1, 60, by=1)

polym <- iNEXT(raw_list, q=0, datatype="incidence_raw", size=t)

# Sample‐size‐based R/E curves
g<-ggiNEXT(polym,type=1, color.var="Assemblage") +
  #scale_y_continuous(limits = c(0, 400), breaks = seq(0, 400, by = 100))+
  theme_bw(base_size = 18) +
  scale_shape_manual(values=c(19,19,19,19,19))+
  xlab("Technical Replicates")+
  ylab("Richness")+
  theme(legend.position="bottom",
        legend.title=element_blank(),
        text=element_text(size=18),
        legend.box = "vertical")+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        plot.title = element_text(hjust = 0.5),
        axis.line = element_line(color = "grey80"),
        axis.ticks = element_line(color = "grey80"))

assign(Name_of_Run, g)

print(paste("Object", Name_of_Run, "created"))

}

if (Extrapolation == FALSE) {

#Function needed
  tidy_specaccum <- function(x) {
    data.frame(
      site = x$sites,
      richness = x$richness,
      sd = x$sd)
  }
  
  
#Concatenate the Replicate + Richness column with the filtered dataset
data <- data.frame(Replicate = Raw.Richness$Replicate, Richness = Raw.Richness$Raw.Richness,
                   filtered_data)

##### ONE NATURAL REPLICATE #####

# Select  natural replicate with smallest value
one_natural_replicate <- data %>%
  group_by(Replicate) %>%
  slice_min(order_by = Richness, n = 1) ; one_natural_replicate <- one_natural_replicate[-11,]

# Replace the number 2 with 1 in the entire data frame
one_natural_replicate <- one_natural_replicate %>%
  mutate_at(vars(3:ncol(.)), ~ replace(., . > 1, 1)) %>% data.frame()

one_natural_replicate <- one_natural_replicate[,-c(1:2)]

# Fit rarefaction curves with vegan
sac <- specaccum(one_natural_replicate)

# Tidying
one <- tidy_specaccum(sac)

one$replicate <- rep("One",nrow(one))

##### TWO NATURAL REPLICATES #####

# Select and sum the three natural replicates wit smallest values
two_natural_replicates <- data %>%
  group_by(Replicate) %>%
  slice_min(order_by = Richness, n = 2) ; two_natural_replicates <- two_natural_replicates[-13,]

# Replace the number 2 with 1 in the entire data frame
two_natural_replicates <- two_natural_replicates %>%
  mutate_at(vars(3:ncol(.)), ~ replace(., . > 1, 1)) %>% data.frame()

two_natural_replicates <- two_natural_replicates[,-c(1:2)]

# Fit rarefaction curves with vegan
sac <- specaccum(two_natural_replicates)

# Tidying
two <- tidy_specaccum(sac)

two$replicate <- rep("Two",nrow(two))

##### THREE NATURAL REPLICATES #####

# Select and sum the three natural replicates wit smallest values
three_natural_replicates <- data %>%
  group_by(Replicate) %>%
  slice_min(order_by = Richness, n = 3)

# Replace the number 2 with 1 in the entire data frame
three_natural_replicates <- three_natural_replicates %>%
  mutate_at(vars(3:ncol(.)), ~ replace(., . > 1, 1)) %>% data.frame()

three_natural_replicates <- three_natural_replicates[,-c(1:2)]

# Fit rarefaction curves with vegan
sac <- specaccum(three_natural_replicates)

# Tidying
three <- tidy_specaccum(sac)

three$replicate <- rep("Three",nrow(three))

##### FOUR NATURAL REPLICATES #####

# Select and sum the four natural replicates wit smallest values
four_natural_replicates <- data %>%
  group_by(Replicate) %>%
  slice_min(order_by = Richness, n = 4)

# Replace the number 2 with 1 in the entire data frame
four_natural_replicates <- four_natural_replicates %>%
  mutate_at(vars(3:ncol(.)), ~ replace(., . > 1, 1)) %>% data.frame()

four_natural_replicates <- four_natural_replicates[,-c(1:2)]

# Fit rarefaction curves with vegan
sac <- specaccum(four_natural_replicates)

# Tidying
four <- tidy_specaccum(sac)

four$replicate <- rep("Four",nrow(four))

##### FIVE NATURAL REPLICATES #####

# Select and sum the five natural replicates wit smallest values
five_natural_replicates <- data %>%
  group_by(Replicate) %>%
  slice_min(order_by = Richness, n = 5)

# Replace the number 2 with 1 in the entire data frame
five_natural_replicates <- five_natural_replicates %>%
  mutate_at(vars(3:ncol(.)), ~ replace(., . > 1, 1)) %>% data.frame()

five_natural_replicates <- five_natural_replicates[,-c(1:2)]

# Fit rarefaction curves with vegan
sac <- specaccum(five_natural_replicates)

# Tidying
five <- tidy_specaccum(sac)

five$replicate <- rep("Five",nrow(five))

#Merge datasets

polymerases <- data.frame(rbind(one,two,three,four,five))

############  Plot  #######################

#last_points <- polymerases %>%
#  group_by(replicate) %>%
#  summarise(last_site = max(site),
#            last_richness = last(richness))

last_points <- polymerases %>%
  group_by(replicate) %>%
  filter(site == max(site)) %>%
  slice(1) %>%
  ungroup() %>%
  mutate(last_site = site, last_richness = richness) %>%
  dplyr::select(replicate, last_site, last_richness)

g <- polymerases %>%
  ggplot(aes(site, richness, color = replicate)) +
  scale_x_continuous(expand = c(0, 0)) +
  scale_y_continuous(limits = c(0, 250), breaks = seq(0, 250, by = 50))+
  geom_line(size = 1.2) +
  geom_point(data = last_points, aes(x = last_site, y = last_richness, color = replicate), size = 4) +
  geom_ribbon(aes(ymin = richness - 0.7 * sd, ymax = richness + 0.7 * sd, fill = replicate), color = NA, alpha = 0.3) +
  coord_cartesian(xlim = c(min(polymerases$site), max(polymerases$site) + 1)) +  # Ajusta o limite final do eixo x
  xlab("Technical Replicates") + 
  ylab("Richness") + 
  #ggtitle(paste(Name_of_Run)) +  # Adiciona o título ao gráfico
  theme(
    legend.position = "bottom",
    legend.title = element_blank(),
    text = element_text(size = 18),
    legend.box = "vertical",
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_blank(),
    plot.title = element_text(hjust = 0.5),
    axis.line = element_line(color = "grey80"),
    axis.ticks = element_line(color = "grey80"),
    panel.background = element_rect(fill = "white")
  )

assign(Name_of_Run, g)

polymerases$sample_polymerase <- rep(Name_of_Run, nrow(polymerases))

assign(paste0(Name_of_Run,"_df"), polymerases)

print(paste("Object", Name_of_Run, "created"))

}



