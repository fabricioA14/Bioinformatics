## Impacts of replicates, polymerase and amplicon size to unravel species richness across habitats using eDNA metabarcoding ##
## Anmarkrud, J.A.; Thorbek, L.; Schrøder-Nielsen, A.; Rosa, F.A.S.; Melo, S.; Ready, J.S.; de Boer, H.; Mauvisseau Q.; ######
## Corresponding author: Quentin Mauvisseau - quentin.mauvisseau@nhm.uio.no  #################################################

# Load required packages
pack <- c('tibble','stringr','data.table','DescTools','writexl','dplyr','ggplot2','car',
          'MASS','ggpubr','dunn.test','gridExtra')
vars <- pack[!(pack %in% installed.packages()[, "Package"])]
if (length(vars != 0)) {
  install.packages(vars, dependencies = TRUE)
} 
sapply(pack, require, character.only = TRUE)

######################################## COI ########################################

setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_all/violin")

######################## OTUs ########################

csv <- read.csv("ntc.filter.otu.coi.dataset.csv",na.strings = c(""),stringsAsFactors = FALSE, sep = ",")

# Transpose the CSV file
csv <- data.frame(t(csv))

# Add 'Sampling_Unit' as a new column
rra <- csv %>% add_column(Sampling_Unit = rownames(csv), .before = 1) %>% type.convert()

# Create a frequency matrix where any non-zero values become 1
Freq.O <- rra[,-1] ; Freq.O[Freq.O != 0] <- 1

# Add back the 'Sampling_Unit' column
Freq.O <- Freq.O %>% add_column(Sampling_Unit = rra[,1], .before = 1) %>% 
  type.convert() %>% data.frame()

# Richness calculation
Raw.Richness <- Freq.O %>% add_column(Raw.Richness = rowSums(Freq.O[,2:ncol(Freq.O)]), .before = 2) 

Raw.Richness <- Raw.Richness[,1:2]

# Define sample types based on 'Sampling_Unit'
Raw.Richness$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Raw.Richness$Sampling_Unit), "Marine", 
                                   ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Raw.Richness$Sampling_Unit), 
                                          "Freshwater", "Soil"))

# Define polymerase types
Raw.Richness$Polymerase <- ifelse(grepl("AG", Raw.Richness$Sampling_Unit), "AG", 
                                  ifelse(grepl("ACCU", Raw.Richness$Sampling_Unit), 
                                         "ACCU", "QPOL5"))

# Create a data subset for OTUs
otus <- Raw.Richness

# Add method labels for OTUs
otus$Method <- rep("Otus", 450)

# Subset data for different sample types
Freshwater <- Raw.Richness[Raw.Richness$Sample_Type == "Freshwater",]
Soil <- Raw.Richness[Raw.Richness$Sample_Type == "Soil",]
Marine <- Raw.Richness[Raw.Richness$Sample_Type == "Marine",]


####### Soil #######

# Kruskal-Wallis test for soil samples
capture.output(print(kruskal.test(Soil$Raw.Richness ~ Soil$Polymerase)), file = "kruskal_soil_otu.txt")

# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Soil$Raw.Richness, Soil$Polymerase, method = "bonferroni")), file = "dunn_soil_otu.txt")

####### Marine #######

# Kruskal-Wallis test for marine samples
capture.output(print(kruskal.test(Marine$Raw.Richness ~ Marine$Polymerase)), file = "kruskal_marine_otu.txt")

# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Marine$Raw.Richness, Marine$Polymerase, method = "bonferroni")), file = "dunn_marine_otu.txt")

####### Freshwater #######

# Kruskal-Wallis test for freshwater samples
capture.output(print(kruskal.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "kruskal_freshwater_otu.txt")

# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "dunn_freshwater_otu.txt")


######################## ASVs ########################

csv <- read.csv("ntc.filter.zotu.coi.dataset.csv",na.strings = c(""),stringsAsFactors = FALSE, sep = ",")

# Transpose the CSV file
csv <- data.frame(t(csv))

# Add 'Sampling_Unit' as a new column
rra <- csv %>% add_column(Sampling_Unit = rownames(csv), .before = 1) %>% type.convert()

# Create a frequency matrix where any non-zero values become 1
Freq.O <- rra[,-1] ; Freq.O[Freq.O != 0] <- 1

# Add back the 'Sampling_Unit' column
Freq.O <- Freq.O %>% add_column(Sampling_Unit = rra[,1], .before = 1) %>% 
  type.convert() %>% data.frame()

# Richness calculation
Raw.Richness <- Freq.O %>% add_column(Raw.Richness = rowSums(Freq.O[,2:ncol(Freq.O)]), .before = 2) 

Raw.Richness <- Raw.Richness[,1:2]

# Define sample types based on 'Sampling_Unit'
Raw.Richness$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Raw.Richness$Sampling_Unit), "Marine", 
                                   ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Raw.Richness$Sampling_Unit), 
                                          "Freshwater", "Soil"))

# Define polymerase types
Raw.Richness$Polymerase <- ifelse(grepl("AG", Raw.Richness$Sampling_Unit), "AG", 
                                  ifelse(grepl("ACCU", Raw.Richness$Sampling_Unit), 
                                         "ACCU", "QPOL5"))

# Create a data subset for ZOTUs
zotus <- Raw.Richness

# Add method labels for ZOTUs
zotus$Method <- rep("Zotus", 450)

# Subset data for different sample types
Freshwater <- Raw.Richness[Raw.Richness$Sample_Type == "Freshwater",]
Soil <- Raw.Richness[Raw.Richness$Sample_Type == "Soil",]
Marine <- Raw.Richness[Raw.Richness$Sample_Type == "Marine",]


####### Soil #######

# Kruskal-Wallis test for soil samples
capture.output(print(kruskal.test(Soil$Raw.Richness ~ Soil$Polymerase)), file = "kruskal_soil_asv.txt")

# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Soil$Raw.Richness, Soil$Polymerase, method = "bonferroni")), file = "dunn_soil_asv.txt")

####### Marine #######

# Kruskal-Wallis test for marine samples
capture.output(print(kruskal.test(Marine$Raw.Richness ~ Marine$Polymerase)), file = "kruskal_marine_asv.txt")

# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Marine$Raw.Richness, Marine$Polymerase, method = "bonferroni")), file = "dunn_marine_asv.txt")

####### Freshwater #######

# Kruskal-Wallis test for freshwater samples
capture.output(print(kruskal.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "kruskal_freshwater_asv.txt")
               
# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "dunn_freshwater_asv.txt")
               
######### VIOLIN #########

# Combine OTUs and ZOTUs data
all_methods <- rbind(otus,zotus)

# Define the order of the polymerases
all_methods$Polymerase <- factor(all_methods$Polymerase, levels = c("ACCU", "QPOL5", "AG"))

# Generate the violin plot for OTUs
OTU <- ggplot(subset(all_methods, all_methods$Method == "Otus"), aes(x = interaction(Polymerase, Sample_Type), y = Raw.Richness, color = Polymerase, fill = Polymerase)) +
    geom_violin(trim = FALSE, size = 1.1, alpha = 0.2, bounds = c(min(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE), 
                    max(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE))) +
  scale_y_continuous(limits = c(0, 6500), breaks = seq(0, 6500, by = 1500)) +
  stat_summary(fun = "mean", geom = "point", shape = "[", size = 4, color = "grey40") + 
    stat_summary(fun = "mean", geom = "point", shape = "]", size = 4, color = "grey40") + 
    ggtitle("COI")+
  xlab("Sample Type and Polymerase") +  
  ylab("Raw Richness") +               
  theme_minimal() +                    
  theme(axis.text.x = element_text(angle = 45, hjust = 1))+
  theme(plot.title = element_text(hjust = 0.5, size = 20, face = "bold"))

# Generate the violin plot for ZOTUs
ASV <- ggplot(subset(all_methods, all_methods$Method == "Zotus"), aes(x = interaction(Polymerase, Sample_Type), y = Raw.Richness, color = Polymerase, fill = Polymerase)) +
  geom_violin(trim = FALSE, size = 1.1, alpha = 0.2, bounds = c(min(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE), 
                    max(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE))) +
  scale_y_continuous(limits = c(0, 6500), breaks = seq(0, 6500, by = 1500)) +
  stat_summary(fun = "mean", geom = "point", shape = "[", size = 4, color = "grey40") + 
    stat_summary(fun = "mean", geom = "point", shape = "]", size = 4, color = "grey40") + 
  xlab("Sample Type and Polymerase") +  
  ylab("Raw Richness") +               
  theme_minimal() +                    
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

grid.arrange(OTU, ASV, ncol = 2)


######################################## 12s ########################################

setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_all/violin")

######################## OTUs ########################

csv <- read.csv("ntc.filter.otu.12s.dataset.csv",na.strings = c(""),stringsAsFactors = FALSE, sep = ",")

# Transpose the CSV data
csv <- data.frame(t(csv))

# Add 'Sampling_Unit' as a new column
rra <- csv %>% add_column(Sampling_Unit = rownames(csv), .before = 1) %>% type.convert()

# Create a frequency matrix where any non-zero values become 1
Freq.O <- rra[,-1] ; Freq.O[Freq.O != 0] <- 1

# Add back the 'Sampling_Unit' column
Freq.O <- Freq.O %>% add_column(Sampling_Unit = rra[,1], .before = 1) %>% 
  type.convert() %>% data.frame()

# Richness calculation
Raw.Richness <- Freq.O %>% add_column(Raw.Richness = rowSums(Freq.O[,2:ncol(Freq.O)]), .before = 2) 

Raw.Richness <- Raw.Richness[,1:2]

# Define sample types based on 'Sampling_Unit'
Raw.Richness$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Raw.Richness$Sampling_Unit), "Marine", 
                                   ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Raw.Richness$Sampling_Unit), 
                                          "Freshwater", "Soil"))

# Define polymerase types
Raw.Richness$Polymerase <- ifelse(grepl("AG", Raw.Richness$Sampling_Unit), "AG", 
                                  ifelse(grepl("ACCU", Raw.Richness$Sampling_Unit), 
                                         "ACCU", "QPOL5"))

# Create a data subset for OTUs
otus <- Raw.Richness

# Add method labels for OTUs
otus$Method <- rep("Otus", 450)

# Subset data for different sample types
Freshwater <- Raw.Richness[Raw.Richness$Sample_Type == "Freshwater",]
Soil <- Raw.Richness[Raw.Richness$Sample_Type == "Soil",]
Marine <- Raw.Richness[Raw.Richness$Sample_Type == "Marine",]


####### Soil #######

# Kruskal-Wallis test for soil samples
capture.output(print(kruskal.test(Soil$Raw.Richness ~ Soil$Polymerase)), file = "kruskal_soil_otu.txt")

# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Soil$Raw.Richness, Soil$Polymerase, method = "bonferroni")), file = "dunn_soil_otu.txt")

####### Marine #######

# Kruskal-Wallis test for marine samples
capture.output(print(kruskal.test(Marine$Raw.Richness ~ Marine$Polymerase)), file = "kruskal_marine_otu.txt")

# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Marine$Raw.Richness, Marine$Polymerase, method = "bonferroni")), file = "dunn_marine_otu.txt")

####### Freshwater #######

# Kruskal-Wallis test for freshwater samples
capture.output(print(kruskal.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "kruskal_freshwater_otu.txt")

# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "dunn_freshwater_otu.txt")


######################## ASVs ########################

csv <- read.csv("ntc.filter.zotu.12s.dataset.csv",na.strings = c(""),stringsAsFactors = FALSE, sep = ",")

# Transpose the CSV data
csv <- data.frame(t(csv))

# Add 'Sampling_Unit' as a new column
rra <- csv %>% add_column(Sampling_Unit = rownames(csv), .before = 1) %>% type.convert()

# Create a frequency matrix where any non-zero values become 1
Freq.O <- rra[,-1] ; Freq.O[Freq.O != 0] <- 1

# Add back the 'Sampling_Unit' column
Freq.O <- Freq.O %>% add_column(Sampling_Unit = rra[,1], .before = 1) %>% 
  type.convert() %>% data.frame()

# Richness calculation
Raw.Richness <- Freq.O %>% add_column(Raw.Richness = rowSums(Freq.O[,2:ncol(Freq.O)]), .before = 2) 

Raw.Richness <- Raw.Richness[,1:2]

# Define sample types based on 'Sampling_Unit'
Raw.Richness$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Raw.Richness$Sampling_Unit), "Marine", 
                                   ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Raw.Richness$Sampling_Unit), 
                                          "Freshwater", "Soil"))

# Define polymerase types
Raw.Richness$Polymerase <- ifelse(grepl("AG", Raw.Richness$Sampling_Unit), "AG", 
                                  ifelse(grepl("ACCU", Raw.Richness$Sampling_Unit), 
                                         "ACCU", "QPOL5"))

# Create a data subset for ZOTUs
zotus <- Raw.Richness

# Add method labels for ZOTUs
zotus$Method <- rep("Zotus", 450)

# Subset data for different sample types
Freshwater <- Raw.Richness[Raw.Richness$Sample_Type == "Freshwater",]
Soil <- Raw.Richness[Raw.Richness$Sample_Type == "Soil",]
Marine <- Raw.Richness[Raw.Richness$Sample_Type == "Marine",]


####### Soil #######

# Kruskal-Wallis test for soil samples
capture.output(print(kruskal.test(Soil$Raw.Richness ~ Soil$Polymerase)), file = "kruskal_soil_asv.txt")

# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Soil$Raw.Richness, Soil$Polymerase, method = "bonferroni")), file = "dunn_soil_asv.txt")

####### Marine #######

# Kruskal-Wallis test for marine samples
capture.output(print(kruskal.test(Marine$Raw.Richness ~ Marine$Polymerase)), file = "kruskal_marine_asv.txt")

# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Marine$Raw.Richness, Marine$Polymerase, method = "bonferroni")), file = "dunn_marine_asv.txt")

####### Freshwater #######

# Kruskal-Wallis test for freshwater samples
capture.output(print(kruskal.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "kruskal_freshwater_asv.txt")
               
# Perform Dunn's test for multiple comparisons with Bonferroni correction
capture.output(print(dunn.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "dunn_freshwater_asv.txt")
               
######### VIOLIN #########

# Combine OTUs and ZOTUs data
all_methods <- rbind(otus,zotus)

# Generate the violin plot for OTUs
OTU_12s <- ggplot(subset(all_methods, all_methods$Method == "Otus"), aes(x = interaction(Polymerase, Sample_Type), y = Raw.Richness, color = Polymerase, fill = Polymerase)) +
  geom_violin(trim = FALSE, size = 1.1, alpha = 0.2, bounds = c(min(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE), 
                    max(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE))) + 
  scale_y_continuous(limits = c(0, 300), breaks = seq(0, 300, by = 100)) +
  stat_summary(fun = "mean", geom = "point", shape = "[", size = 4, color = "grey40") +  
    stat_summary(fun = "mean", geom = "point", shape = "]", size = 4, color = "grey40") + 
    ggtitle("12S")+
  xlab("Sample Type and Polymerase") +  
  ylab("Raw Richness") +                
  theme_minimal() +                     
  theme(axis.text.x = element_text(angle = 45, hjust = 1))+
  theme(plot.title = element_text(hjust = 0.5, size = 20, face = "bold"))

# Generate the violin plot for ZOTUs
ASV_12s <- ggplot(subset(all_methods, all_methods$Method == "Zotus"), aes(x = interaction(Polymerase, Sample_Type), y = Raw.Richness, color = Polymerase, fill = Polymerase)) +
  geom_violin(trim = FALSE, size = 1.1, alpha = 0.2, bounds = c(min(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE), 
                    max(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE))) +
  scale_y_continuous(limits = c(0, 300), breaks = seq(0, 300, by = 100)) +
  stat_summary(fun = "mean", geom = "point", shape = "[", size = 4, color = "grey40") +  
    stat_summary(fun = "mean", geom = "point", shape = "]", size = 4, color = "grey40") + 
  xlab("Sample Type and Polymerase") +  
  ylab("Raw Richness") +                
  theme_minimal() +                     
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Arrange both violin plots vertically
grid.arrange(OTU_12s, ASV_12s, ncol = 1)

