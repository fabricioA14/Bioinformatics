## Impacts of replicates, polymerase and amplicon size to unravel species richness across habitats using eDNA metabarcoding ##
## Anmarkrud, J.A.; Thorbek, L.; Schrøder-Nielsen, A.; Rosa, F.A.S.; Melo, S.; Ready, J.S.; de Boer, H.; Mauvisseau Q.; ######
## Corresponding author: Quentin Mauvisseau - quentin.mauvisseau@nhm.uio.no  #################################################

# Load packages
pack <- c('tibble','stringr','data.table','DescTools','writexl','dplyr','ggplot2','car',
          'MASS','ggpubr','dunn.test','gridExtra')
vars <- pack[!(pack %in% installed.packages()[, "Package"])]
if (length(vars != 0)) {
  install.packages(vars, dependencies = TRUE)
} 
sapply(pack, require, character.only = TRUE)

######################################## COI ########################################

setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/coi_all/violin")

######################## OTUs ########################

csv <- read.csv("ntc.filter.otu.coi.dataset.csv",na.strings = c(""),stringsAsFactors = FALSE, sep = ",")

csv <- data.frame(t(csv))

rra <- csv %>% add_column(Sampling_Unit = rownames(csv), .before = 1) %>% type.convert()

Freq.O <- rra[,-1] ; Freq.O[Freq.O != 0] <- 1

Freq.O <- Freq.O %>% add_column(Sampling_Unit = rra[,1], .before = 1) %>% 
  type.convert() %>% data.frame()

# Richness
Raw.Richness <- Freq.O %>% add_column(Raw.Richness = rowSums(Freq.O[,2:ncol(Freq.O)]), .before = 2) 

Raw.Richness <- Raw.Richness[,1:2]

Raw.Richness$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Raw.Richness$Sampling_Unit), "Marine", 
                                   ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Raw.Richness$Sampling_Unit), 
                                          "Freshwater", "Soil"))
Raw.Richness$Polymerase <- ifelse(grepl("AG", Raw.Richness$Sampling_Unit), "AG", 
                                  ifelse(grepl("ACCU", Raw.Richness$Sampling_Unit), 
                                         "ACCU", "QPOL5"))

otus <- Raw.Richness

otus$Method <- rep("Otus", 450)

Freshwater <- Raw.Richness[Raw.Richness$Sample_Type == "Freshwater",]
Soil <- Raw.Richness[Raw.Richness$Sample_Type == "Soil",]
Marine <- Raw.Richness[Raw.Richness$Sample_Type == "Marine",]


####### Soil #######

# Kruskal 
capture.output(print(kruskal.test(Soil$Raw.Richness ~ Soil$Polymerase)), file = "kruskal_soil_otu.txt")

# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Soil$Raw.Richness, Soil$Polymerase, method = "bonferroni")), file = "dunn_soil_otu.txt")

####### Marine #######

# Kruskal 
capture.output(print(kruskal.test(Marine$Raw.Richness ~ Marine$Polymerase)), file = "kruskal_marine_otu.txt")

# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Marine$Raw.Richness, Marine$Polymerase, method = "bonferroni")), file = "dunn_marine_otu.txt")

####### Freshwater #######

# Kruskal 
capture.output(print(kruskal.test(Freshwater$Raw.Richness ~ Freshwater$Polymerase)), file = "kruskal_freshwater_otu.txt")

# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "dunn_freshwater_otu.txt")


######################## ASVs ########################

csv <- read.csv("ntc.filter.zotu.coi.dataset.csv",na.strings = c(""),stringsAsFactors = FALSE, sep = ",")

csv <- data.frame(t(csv))

rra <- csv %>% add_column(Sampling_Unit = rownames(csv), .before = 1) %>% type.convert()

Freq.O <- rra[,-1] ; Freq.O[Freq.O != 0] <- 1

Freq.O <- Freq.O %>% add_column(Sampling_Unit = rra[,1], .before = 1) %>% 
  type.convert() %>% data.frame()

# Richness
Raw.Richness <- Freq.O %>% add_column(Raw.Richness = rowSums(Freq.O[,2:ncol(Freq.O)]), .before = 2) 

Raw.Richness <- Raw.Richness[,1:2]

Raw.Richness$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Raw.Richness$Sampling_Unit), "Marine", 
                                   ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Raw.Richness$Sampling_Unit), 
                                          "Freshwater", "Soil"))
Raw.Richness$Polymerase <- ifelse(grepl("AG", Raw.Richness$Sampling_Unit), "AG", 
                                  ifelse(grepl("ACCU", Raw.Richness$Sampling_Unit), 
                                         "ACCU", "QPOL5"))

zotus <- Raw.Richness

zotus$Method <- rep("Zotus", 450)

Freshwater <- Raw.Richness[Raw.Richness$Sample_Type == "Freshwater",]
Soil <- Raw.Richness[Raw.Richness$Sample_Type == "Soil",]
Marine <- Raw.Richness[Raw.Richness$Sample_Type == "Marine",]


####### Soil #######

# Kruskal 
capture.output(print(kruskal.test(Soil$Raw.Richness ~ Soil$Polymerase)), file = "kruskal_soil_asv.txt")

# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Soil$Raw.Richness, Soil$Polymerase, method = "bonferroni")), file = "dunn_soil_asv.txt")

####### Marine #######

# Kruskal 
capture.output(print(kruskal.test(Marine$Raw.Richness ~ Marine$Polymerase)), file = "kruskal_marine_asv.txt")

# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Marine$Raw.Richness, Marine$Polymerase, method = "bonferroni")), file = "dunn_marine_asv.txt")

####### Freshwater #######

# Kruskal 
capture.output(print(kruskal.test(Freshwater$Raw.Richness ~ Freshwater$Polymerase)), file = "kruskal_freshwater_asv.txt")
               
# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "dunn_freshwater_asv.txt")
               
######### VIOLIN #########
               
all_methods <- rbind(otus,zotus)

#library(gridExtra)

# Generate the violin plot
OTU <- ggplot(subset(all_methods, all_methods$Method == "Otus"), aes(x = interaction(Polymerase, Sample_Type), y = Raw.Richness, color = Polymerase, fill = Polymerase)) +
    geom_violin(trim = FALSE, size = 1.1, alpha = 0.2, bounds = c(min(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE), 
                    max(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE))) +
  stat_summary(fun = "mean", geom = "point", shape = "[", size = 4, color = "grey40") + 
    stat_summary(fun = "mean", geom = "point", shape = "]", size = 4, color = "grey40") + 
    ggtitle("COI")+
  xlab("Sample Type and Polymerase") +  
  ylab("Raw Richness") +                
  theme_minimal() +                     
  theme(axis.text.x = element_text(angle = 45, hjust = 1))+
  theme(plot.title = element_text(hjust = 0.5, size = 20, face = "bold"))#+
  #theme(legend.position = "bottom")

ASV <- ggplot(subset(all_methods, all_methods$Method == "Zotus"), aes(x = interaction(Polymerase, Sample_Type), y = Raw.Richness, color = Polymerase, fill = Polymerase)) +
  geom_violin(trim = FALSE, size = 1.1, alpha = 0.2, bounds = c(min(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE), 
                    max(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE))) +
  stat_summary(fun = "mean", geom = "point", shape = "[", size = 4, color = "grey40") + 
    stat_summary(fun = "mean", geom = "point", shape = "]", size = 4, color = "grey40") + 
  xlab("Sample Type and Polymerase") + 
  ylab("Raw Richness") +               
  theme_minimal() +                     
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


######################################## 12s ########################################

setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/12s_all/violin")

######################## OTUs ########################

csv <- read.csv("ntc.filter.otu.12s.dataset.csv",na.strings = c(""),stringsAsFactors = FALSE, sep = ",")

csv <- data.frame(t(csv))

rra <- csv %>% add_column(Sampling_Unit = rownames(csv), .before = 1) %>% type.convert()

Freq.O <- rra[,-1] ; Freq.O[Freq.O != 0] <- 1

Freq.O <- Freq.O %>% add_column(Sampling_Unit = rra[,1], .before = 1) %>% 
  type.convert() %>% data.frame()

# Richness
Raw.Richness <- Freq.O %>% add_column(Raw.Richness = rowSums(Freq.O[,2:ncol(Freq.O)]), .before = 2) 

Raw.Richness <- Raw.Richness[,1:2]

Raw.Richness$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Raw.Richness$Sampling_Unit), "Marine", 
                                   ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Raw.Richness$Sampling_Unit), 
                                          "Freshwater", "Soil"))
Raw.Richness$Polymerase <- ifelse(grepl("AG", Raw.Richness$Sampling_Unit), "AG", 
                                  ifelse(grepl("ACCU", Raw.Richness$Sampling_Unit), 
                                         "ACCU", "QPOL5"))

otus <- Raw.Richness

otus$Method <- rep("Otus", 450)

Freshwater <- Raw.Richness[Raw.Richness$Sample_Type == "Freshwater",]
Soil <- Raw.Richness[Raw.Richness$Sample_Type == "Soil",]
Marine <- Raw.Richness[Raw.Richness$Sample_Type == "Marine",]


####### Soil #######

# Kruskal 
capture.output(print(kruskal.test(Soil$Raw.Richness ~ Soil$Polymerase)), file = "kruskal_soil_otu.txt")

# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Soil$Raw.Richness, Soil$Polymerase, method = "bonferroni")), file = "dunn_soil_otu.txt")

####### Marine #######

# Kruskal 
capture.output(print(kruskal.test(Marine$Raw.Richness ~ Marine$Polymerase)), file = "kruskal_marine_otu.txt")

# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Marine$Raw.Richness, Marine$Polymerase, method = "bonferroni")), file = "dunn_marine_otu.txt")

####### Freshwater #######

# Kruskal 
capture.output(print(kruskal.test(Freshwater$Raw.Richness ~ Freshwater$Polymerase)), file = "kruskal_freshwater_otu.txt")

# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "dunn_freshwater_otu.txt")


######################## ASVs ########################

csv <- read.csv("ntc.filter.zotu.12s.dataset.csv",na.strings = c(""),stringsAsFactors = FALSE, sep = ",")

csv <- data.frame(t(csv))

rra <- csv %>% add_column(Sampling_Unit = rownames(csv), .before = 1) %>% type.convert()

Freq.O <- rra[,-1] ; Freq.O[Freq.O != 0] <- 1

Freq.O <- Freq.O %>% add_column(Sampling_Unit = rra[,1], .before = 1) %>% 
  type.convert() %>% data.frame()

# Richness
Raw.Richness <- Freq.O %>% add_column(Raw.Richness = rowSums(Freq.O[,2:ncol(Freq.O)]), .before = 2) 

Raw.Richness <- Raw.Richness[,1:2]

Raw.Richness$Sample_Type <- ifelse(grepl("S1_|S2_|S3_|S4_|S5_", Raw.Richness$Sampling_Unit), "Marine", 
                                   ifelse(grepl("S6_|S7_|S8_|S9_|S10_", Raw.Richness$Sampling_Unit), 
                                          "Freshwater", "Soil"))
Raw.Richness$Polymerase <- ifelse(grepl("AG", Raw.Richness$Sampling_Unit), "AG", 
                                  ifelse(grepl("ACCU", Raw.Richness$Sampling_Unit), 
                                         "ACCU", "QPOL5"))

zotus <- Raw.Richness

zotus$Method <- rep("Zotus", 450)

Freshwater <- Raw.Richness[Raw.Richness$Sample_Type == "Freshwater",]
Soil <- Raw.Richness[Raw.Richness$Sample_Type == "Soil",]
Marine <- Raw.Richness[Raw.Richness$Sample_Type == "Marine",]


####### Soil #######

# Kruskal 
capture.output(print(kruskal.test(Soil$Raw.Richness ~ Soil$Polymerase)), file = "kruskal_soil_asv.txt")

# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Soil$Raw.Richness, Soil$Polymerase, method = "bonferroni")), file = "dunn_soil_asv.txt")

####### Marine #######

# Kruskal 
capture.output(print(kruskal.test(Marine$Raw.Richness ~ Marine$Polymerase)), file = "kruskal_marine_asv.txt")

# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Marine$Raw.Richness, Marine$Polymerase, method = "bonferroni")), file = "dunn_marine_asv.txt")

####### Freshwater #######

# Kruskal 
capture.output(print(kruskal.test(Freshwater$Raw.Richness ~ Freshwater$Polymerase)), file = "kruskal_freshwater_asv.txt")
               
# Perform Dunn's test for multiple comparisons
capture.output(print(dunn.test(Freshwater$Raw.Richness, Freshwater$Polymerase, method = "bonferroni")), file = "dunn_freshwater_asv.txt")
               
######### VIOLIN #########
               
all_methods <- rbind(otus,zotus)

#library(gridExtra)

# Generate the violin plot
OTU_12s <- ggplot(subset(all_methods, all_methods$Method == "Otus"), aes(x = interaction(Polymerase, Sample_Type), y = Raw.Richness, color = Polymerase, fill = Polymerase)) +
  geom_violin(trim = FALSE, size = 1.1, alpha = 0.2, bounds = c(min(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE), 
                    max(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE))) +  
  stat_summary(fun = "mean", geom = "point", shape = "[", size = 4, color = "grey40") +  
    stat_summary(fun = "mean", geom = "point", shape = "]", size = 4, color = "grey40") + 
    ggtitle("12S")+
  xlab("Sample Type and Polymerase") + 
  ylab("Raw Richness") +             
  theme_minimal() +                    
  theme(axis.text.x = element_text(angle = 45, hjust = 1))+
  theme(plot.title = element_text(hjust = 0.5, size = 20, face = "bold"))


ASV_12s <- ggplot(subset(all_methods, all_methods$Method == "Zotus"), aes(x = interaction(Polymerase, Sample_Type), y = Raw.Richness, color = Polymerase, fill = Polymerase)) +
  geom_violin(trim = FALSE, size = 1.1, alpha = 0.2, bounds = c(min(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE), 
                    max(all_methods$Raw.Richness[all_methods$Method == "Zotus"], na.rm = TRUE))) +  
  stat_summary(fun = "mean", geom = "point", shape = "[", size = 4, color = "grey40") + 
    stat_summary(fun = "mean", geom = "point", shape = "]", size = 4, color = "grey40") + 
  xlab("Sample Type and Polymerase") + 
  ylab("Raw Richness") +                
  theme_minimal() +                 
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# All plots
grid.arrange(OTU, OTU_12s, ASV, ASV_12s, ncol = 2) # 19x10

