## Impacts of replicates, polymerase and amplicon size to unravel species richness across habitats using eDNA metabarcoding ##
## Anmarkrud, J.A.; Thorbek, L.; Schrøder-Nielsen, A.; Rosa, F.A.S.; Melo, S.; Ready, J.S.; de Boer, H.; Mauvisseau Q.; ######
## Corresponding author: Quentin Mauvisseau - quentin.mauvisseau@nhm.uio.no  #################################################

######################################## COI ########################################

################# OTUs #################

# Setting working directories
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu")

# Load required packages
pack <- c('tibble','stringr','data.table','DescTools','writexl','dplyr','ggplot2','car',
          'MASS','ggpubr')
vars <- pack[!(pack %in% installed.packages()[, "Package"])]
if (length(vars != 0)) {
  install.packages(vars, dependencies = TRUE)
} 
sapply(pack, require, character.only = TRUE)

###############################################################################

csv <- read.csv("otutab_COI.txt",na.strings = c(""),stringsAsFactors = FALSE, sep = "")

csv <- csv[,c(2:ncol(csv))]

# Select rows where the sum is more than 10
row_sums <- rowSums(csv, na.rm = TRUE)

filtered_rows <- csv[!row_sums < 10, ]

## Before NTC removal
#sum(as.matrix(csv[, !grepl("^NTC", colnames(csv))]), na.rm = TRUE)

# AG
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern AG
  polymerase <- replicates[, str_detect(colnames(replicates), "AG")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
AG <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# ACCU
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern ACCU
  polymerase <- replicates[, str_detect(colnames(replicates), "ACCU")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
ACCU <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# Q
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern QPOL5
  polymerase <- replicates[, str_detect(colnames(replicates), "QPOL5")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
Q <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

#################################################################

# Combine AG, ACCU, and Q data into one dataset
ntc.filter.dataset <- data.frame(AG, ACCU, Q)

#Sum after NTC removal
#sum(as.matrix(ntc.filter.dataset[, !grepl("^NTC", colnames(ntc.filter.dataset))]), na.rm = TRUE)

# Remove columns with 'NTC' in their names
ntc.filter.dataset_ <- ntc.filter.dataset[, !grepl('NTC', names(ntc.filter.dataset))]

#OTUs sum
#sum(rowSums(ntc.filter.dataset_, na.rm = TRUE) > 0)

# Save the filtered dataset to a CSV file
write.csv(ntc.filter.dataset_, "C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_otu/ntc.filter.otu.coi.dataset.csv", row.names = F)

# Clean up the workspace, removing all objects except the ones specified
rm(list=setdiff(ls(), c("")))


################# ASVs #################

# Setting working directories
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu")

csv <- read.csv("zotutab_COI.txt",na.strings = c(""),stringsAsFactors = FALSE, sep = "")

csv <- csv[,c(2:ncol(csv))]

# Select rows where the sum is more than 10
row_sums <- rowSums(csv, na.rm = TRUE)

filtered_rows <- csv[!row_sums < 10, ]

## Before NTC removal
#sum(as.matrix(csv[, !grepl("^NTC", colnames(csv))]), na.rm = TRUE)

# AG
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern AG
  polymerase <- replicates[, str_detect(colnames(replicates), "AG")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
AG <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# ACCU
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern ACCU
  polymerase <- replicates[, str_detect(colnames(replicates), "ACCU")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
ACCU <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# Q
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern QPOL5
  polymerase <- replicates[, str_detect(colnames(replicates), "QPOL5")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
Q <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

#################################################################

# Combine AG, ACCU, and Q data into one dataset
ntc.filter.dataset <- data.frame(AG, ACCU, Q)

#Sum after NTC removal
#sum(as.matrix(ntc.filter.dataset[, !grepl("^NTC", colnames(ntc.filter.dataset))]), na.rm = TRUE)

# Remove columns with 'NTC' in their names
ntc.filter.dataset_ <- ntc.filter.dataset[, !grepl('NTC', names(ntc.filter.dataset))]

#OTUs sum
sum(rowSums(ntc.filter.dataset_, na.rm = TRUE) > 0)

# Save the filtered dataset to a CSV file
write.csv(ntc.filter.dataset_, "C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/coi_zotu/ntc.filter.zotu.coi.dataset.csv", row.names = F)

# Clean up the workspace, removing all objects except the ones specified
rm(list=setdiff(ls(), c("freq_otu")))


######################################## 12S ########################################

################# OTUs #################

# Setting working directories
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu")

csv <- read.csv("otutab_12S.txt",na.strings = c(""),stringsAsFactors = FALSE, sep = "")

csv <- csv[,c(3:ncol(csv))]

# Select rows where the sum is more than 10
row_sums <- rowSums(csv, na.rm = TRUE)

csv <- csv[!row_sums < 10, ]

#Sum before NTC removal
#sum(as.matrix(csv[, !grepl("^NTC", colnames(csv))]), na.rm = TRUE)

# AG
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern AG
  polymerase <- replicates[, str_detect(colnames(replicates), "AG")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
AG <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# ACCU
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern ACCU
  polymerase <- replicates[, str_detect(colnames(replicates), "ACCU")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
ACCU <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# Q
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern QPOL5
  polymerase <- replicates[, str_detect(colnames(replicates), "QPOL5")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
Q <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

#################################################################

# Combine AG, ACCU, and Q data into one dataset
ntc.filter.dataset <- data.frame(AG, ACCU, Q)

#Sum after NTC removal
#sum(as.matrix(ntc.filter.dataset[, !grepl("^NTC", colnames(ntc.filter.dataset))]), na.rm = TRUE)

# Remove columns with 'NTC' in their names
ntc.filter.dataset_ <- ntc.filter.dataset[, !grepl('NTC', names(ntc.filter.dataset))]

#ZOTUs sum
#sum(rowSums(ntc.filter.dataset_, na.rm = TRUE) > 0)

# Save the filtered dataset to a CSV file
write.csv(ntc.filter.dataset_, "C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_otu/ntc.filter.otu.12S.dataset.csv", row.names = F)

# Clean up the workspace, removing all objects except the ones specified
rm(list=setdiff(ls(), c("")))


################# ASVs #################

# Setting working directories
setwd("C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_zotu")

csv <- read.csv("zotutab_12S.txt",na.strings = c(""),stringsAsFactors = FALSE, sep = "")

csv <- csv[,c(3:ncol(csv))]

# Select rows where the sum is more than 10
row_sums <- rowSums(csv, na.rm = TRUE)

filtered_rows <- csv[!row_sums < 10, ]

#Sum before NTC removal
#sum(as.matrix(csv[, !grepl("^NTC", colnames(csv))]), na.rm = TRUE)

# AG
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern AG
  polymerase <- replicates[, str_detect(colnames(replicates), "AG")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
AG <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# ACCU
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern ACCU
  polymerase <- replicates[, str_detect(colnames(replicates), "ACCU")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
ACCU <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

# Q
# Function to dynamically create objects
for (i in 1:10) {
  
  # Select columns that match the pattern R1_, R2_, etc.
  replicates <- csv[, str_detect(colnames(csv), paste0("R", i, "_"))]
  
  # Filter columns that match the pattern QPOL5
  polymerase <- replicates[, str_detect(colnames(replicates), "QPOL5")]
  
  # Apply the same calculation
  filter.ntc <- polymerase
  for (j in 1:(ncol(polymerase))) {
    filter.ntc[,j] <- polymerase[,j] - polymerase[,1]
  }
  filter.ntc[filter.ntc < 0] <- 0
  
  # Convert the data into the correct format and store in the corresponding object
  assign(paste0("R", i), data.frame(filter.ntc) %>% type.convert())
}

# Create a data frame with all results
Q <- data.frame(R1, R2, R3, R4, R5, R6, R7, R8, R9, R10)

#################################################################

# Combine AG, ACCU, and Q data into one dataset
ntc.filter.dataset <- data.frame(AG, ACCU, Q)

#Sum after NTC removal
#sum(as.matrix(ntc.filter.dataset[, !grepl("^NTC", colnames(ntc.filter.dataset))]), na.rm = TRUE)

# Remove columns with 'NTC' in their names
ntc.filter.dataset_ <- ntc.filter.dataset[, !grepl('NTC', names(ntc.filter.dataset))]

#ZOTUs sum
#sum(rowSums(ntc.filter.dataset_, na.rm = TRUE) > 0)

# Save the filtered dataset to a CSV file
write.csv(ntc.filter.dataset_, "C:/Users/fabricio/OneDrive/Taq/Taq_Results/new_results/1_raw_data/12s_zotu/ntc.filter.zotu.12S.dataset.csv", row.names = F)

# Clean up the workspace, removing all objects except the ones specified
rm(list=setdiff(ls(), c("")))

